<template>
  <layout>
    管理权限页
  </layout>
</template>

<script>
export default {
  
}
</script>